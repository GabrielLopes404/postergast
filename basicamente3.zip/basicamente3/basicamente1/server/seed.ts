import bcrypt from "bcryptjs";
import { storage } from "./storage";
import { db } from "./db";
import { subscriptionPlans } from "../shared/schema";

async function seed() {
  console.log("Starting seed...");

  try {
    const existingUser = await storage.getUserByEmail("demo@lucrei.com");
    
    if (existingUser) {
      console.log("✓ Demo data already exists!");
      console.log("\nLogin credentials:");
      console.log("Email: demo@lucrei.com");
      console.log("Password: demo123");
      console.log("\nOr use:");
      console.log("Email: admin@lucrei.com");
      console.log("Password: demo123");
      process.exit(0);
    }

    // Create default subscription plans
    console.log("Creating subscription plans...");
    const plans = [
      {
        name: "STARTER - Mensal",
        description: "Para freelancers e pequenos negócios - 7 dias grátis",
        price: "47.00",
        billingPeriod: "monthly",
        features: [
          "Até 100 clientes",
          "Faturas ilimitadas",
          "Relatórios básicos",
          "2 usuários",
          "Suporte por email",
          "7 dias de teste grátis"
        ],
        maxUsers: 2,
        maxTransactions: null,
        isActive: true,
        stripePriceId: process.env.STRIPE_PRICE_STARTER_MONTHLY
      },
      {
        name: "STARTER - Anual",
        description: "Para freelancers e pequenos negócios - 7 dias grátis + Economize 17%",
        price: "470.00",
        billingPeriod: "yearly",
        features: [
          "Até 100 clientes",
          "Faturas ilimitadas",
          "Relatórios básicos",
          "2 usuários",
          "Suporte por email",
          "7 dias de teste grátis",
          "Economize 17% no anual"
        ],
        maxUsers: 2,
        maxTransactions: null,
        isActive: true,
        stripePriceId: process.env.STRIPE_PRICE_STARTER_YEARLY
      },
      {
        name: "BUSINESS - Mensal",
        description: "Para empresas em crescimento - 7 dias grátis",
        price: "147.00",
        billingPeriod: "monthly",
        features: [
          "Clientes ilimitados",
          "Faturas ilimitadas",
          "Relatórios avançados (DRE, Fluxo de Caixa)",
          "Até 10 usuários",
          "API de integração",
          "Suporte prioritário",
          "Automação de cobranças",
          "7 dias de teste grátis"
        ],
        maxUsers: 10,
        maxTransactions: null,
        isActive: true,
        stripePriceId: process.env.STRIPE_PRICE_BUSINESS_MONTHLY
      },
      {
        name: "BUSINESS - Anual",
        description: "Para empresas em crescimento - 7 dias grátis + Economize 17%",
        price: "1470.00",
        billingPeriod: "yearly",
        features: [
          "Clientes ilimitados",
          "Faturas ilimitadas",
          "Relatórios avançados (DRE, Fluxo de Caixa)",
          "Até 10 usuários",
          "API de integração",
          "Suporte prioritário",
          "Automação de cobranças",
          "7 dias de teste grátis",
          "Economize 17% no anual"
        ],
        maxUsers: 10,
        maxTransactions: null,
        isActive: true,
        stripePriceId: process.env.STRIPE_PRICE_BUSINESS_YEARLY
      },
    ];

    await db.insert(subscriptionPlans).values(plans);
    console.log("✓ Created 4 subscription plans (STARTER e BUSINESS - Mensal e Anual)");

    // Create branding config
    console.log("Creating default branding...");
    const { brandingConfig } = await import("@shared/schema");
    try {
      await db.insert(brandingConfig).values({
        companyName: "LUCREI",
        logoUrl: null,
        primaryColor: "#0ea5e9",
        secondaryColor: "#06b6d4",
        accentColor: "#14b8a6",
        customDomain: null,
        metaTitle: "LUCREI - Sistema de Gestão Financeira",
        metaDescription: "Sistema completo de gestão financeira para empresas de todos os tamanhos",
        heroTitle: "Gestão Financeira Simplificada",
        heroSubtitle: "Controle suas finanças com inteligência e eficiência",
        contactEmail: "contato@lucrei.com",
        supportEmail: "suporte@lucrei.com",
        whatsapp: "+55 (11) 98765-4321",
        facebookUrl: null,
        instagramUrl: null,
        linkedinUrl: null,
        twitterUrl: null,
        termsUrl: "/termos",
        privacyUrl: "/privacidade",
        customCss: null,
        customHead: null,
      });
      console.log("✓ Created branding config");
    } catch (e) {
      console.log("⚠ Branding config already exists or failed");
    }

    const hashedPassword = await bcrypt.hash("demo123", 10);

    const org = await storage.createOrganization({
      name: "Demo Company",
      email: "demo@lucrei.com",
    });
    console.log("✓ Created organization:", org.name);

    const owner = await storage.createUser({
      username: "demo",
      email: "demo@lucrei.com",
      password: hashedPassword,
      name: "Demo User",
      organizationId: org.id,
      role: "OWNER",
      emailVerified: true,
    });
    console.log("✓ Created owner user:", owner.email);

    const admin = await storage.createUser({
      username: "admin",
      email: "admin@lucrei.com",
      password: hashedPassword,
      name: "Admin User",
      organizationId: org.id,
      role: "ADMIN",
      emailVerified: true,
    });
    console.log("✓ Created admin user:", admin.email);

    const customers = await Promise.all([
      storage.createCustomer({
        name: "João Silva",
        email: "joao@example.com",
        phone: "(11) 98765-4321",
        organizationId: org.id,
      }),
      storage.createCustomer({
        name: "Maria Santos",
        email: "maria@example.com",
        phone: "(21) 99876-5432",
        organizationId: org.id,
      }),
      storage.createCustomer({
        name: "Carlos Oliveira",
        email: "carlos@example.com",
        phone: "(31) 97654-3210",
        organizationId: org.id,
      }),
    ]);
    console.log("✓ Created", customers.length, "customers");

    // Create default categories
    console.log("Creating default categories...");
    const { categories } = await import("@shared/schema");
    const defaultCategories = [
      { name: "Receitas Operacionais", type: "income", organizationId: org.id },
      { name: "Vendas de Produtos", type: "income", organizationId: org.id },
      { name: "Vendas de Serviços", type: "income", organizationId: org.id },
      { name: "Outras Receitas", type: "income", organizationId: org.id },
      { name: "Despesas Administrativas", type: "expense", organizationId: org.id },
      { name: "Salários e Encargos", type: "expense", organizationId: org.id },
      { name: "Aluguel", type: "expense", organizationId: org.id },
      { name: "Energia e Água", type: "expense", organizationId: org.id },
      { name: "Telefone e Internet", type: "expense", organizationId: org.id },
      { name: "Materiais de Escritório", type: "expense", organizationId: org.id },
      { name: "Marketing e Publicidade", type: "expense", organizationId: org.id },
      { name: "Impostos e Taxas", type: "expense", organizationId: org.id },
    ];
    await db.insert(categories).values(defaultCategories);
    console.log("✓ Created", defaultCategories.length, "categories");

    const now = new Date();
    const invoices = await Promise.all([
      // Faturas pagas - meses anteriores
      storage.createInvoice({
        customerId: customers[0].id,
        organizationId: org.id,
        invoiceNumber: `INV-${Date.now()}-001`,
        amount: "1500.00",
        status: "paid",
        issueDate: new Date(now.getFullYear(), now.getMonth() - 4, 5),
        dueDate: new Date(now.getFullYear(), now.getMonth() - 4, 15),
        paidDate: new Date(now.getFullYear(), now.getMonth() - 4, 14),
        description: "Consultoria em desenvolvimento web",
      }),
      storage.createInvoice({
        customerId: customers[1].id,
        organizationId: org.id,
        invoiceNumber: `INV-${Date.now()}-002`,
        amount: "2500.00",
        status: "paid",
        issueDate: new Date(now.getFullYear(), now.getMonth() - 4, 10),
        dueDate: new Date(now.getFullYear(), now.getMonth() - 4, 20),
        paidDate: new Date(now.getFullYear(), now.getMonth() - 4, 18),
        description: "Design de interface e UX",
      }),
      storage.createInvoice({
        customerId: customers[2].id,
        organizationId: org.id,
        invoiceNumber: `INV-${Date.now()}-003`,
        amount: "3200.00",
        status: "paid",
        issueDate: new Date(now.getFullYear(), now.getMonth() - 3, 5),
        dueDate: new Date(now.getFullYear(), now.getMonth() - 3, 15),
        paidDate: new Date(now.getFullYear(), now.getMonth() - 3, 15),
        description: "Manutenção de sistema",
      }),
      storage.createInvoice({
        customerId: customers[0].id,
        organizationId: org.id,
        invoiceNumber: `INV-${Date.now()}-004`,
        amount: "1800.00",
        status: "paid",
        issueDate: new Date(now.getFullYear(), now.getMonth() - 3, 12),
        dueDate: new Date(now.getFullYear(), now.getMonth() - 3, 22),
        paidDate: new Date(now.getFullYear(), now.getMonth() - 3, 20),
        description: "Desenvolvimento de API",
      }),
      storage.createInvoice({
        customerId: customers[1].id,
        organizationId: org.id,
        invoiceNumber: `INV-${Date.now()}-005`,
        amount: "4500.00",
        status: "paid",
        issueDate: new Date(now.getFullYear(), now.getMonth() - 2, 3),
        dueDate: new Date(now.getFullYear(), now.getMonth() - 2, 13),
        paidDate: new Date(now.getFullYear(), now.getMonth() - 2, 10),
        description: "Desenvolvimento de plataforma e-commerce",
      }),
      storage.createInvoice({
        customerId: customers[2].id,
        organizationId: org.id,
        invoiceNumber: `INV-${Date.now()}-006`,
        amount: "2200.00",
        status: "paid",
        issueDate: new Date(now.getFullYear(), now.getMonth() - 2, 18),
        dueDate: new Date(now.getFullYear(), now.getMonth() - 2, 28),
        paidDate: new Date(now.getFullYear(), now.getMonth() - 2, 25),
        description: "Suporte técnico mensal",
      }),
      storage.createInvoice({
        customerId: customers[0].id,
        organizationId: org.id,
        invoiceNumber: `INV-${Date.now()}-007`,
        amount: "5800.00",
        status: "paid",
        issueDate: new Date(now.getFullYear(), now.getMonth() - 1, 2),
        dueDate: new Date(now.getFullYear(), now.getMonth() - 1, 12),
        paidDate: new Date(now.getFullYear(), now.getMonth() - 1, 11),
        description: "Sistema de gestão customizado",
      }),
      storage.createInvoice({
        customerId: customers[1].id,
        organizationId: org.id,
        invoiceNumber: `INV-${Date.now()}-008`,
        amount: "3100.00",
        status: "paid",
        issueDate: new Date(now.getFullYear(), now.getMonth() - 1, 15),
        dueDate: new Date(now.getFullYear(), now.getMonth() - 1, 25),
        paidDate: new Date(now.getFullYear(), now.getMonth() - 1, 24),
        description: "Redesign de interface",
      }),
      storage.createInvoice({
        customerId: customers[2].id,
        organizationId: org.id,
        invoiceNumber: `INV-${Date.now()}-009`,
        amount: "6500.00",
        status: "paid",
        issueDate: new Date(now.getFullYear(), now.getMonth(), 1),
        dueDate: new Date(now.getFullYear(), now.getMonth(), 11),
        paidDate: new Date(now.getFullYear(), now.getMonth(), 10),
        description: "Migração de servidor e infraestrutura",
      }),
      // Faturas pendentes do mês atual
      storage.createInvoice({
        customerId: customers[0].id,
        organizationId: org.id,
        invoiceNumber: `INV-${Date.now()}-010`,
        amount: "2400.00",
        status: "pending",
        issueDate: new Date(now.getFullYear(), now.getMonth(), 5),
        dueDate: new Date(now.getFullYear(), now.getMonth(), 15),
        description: "Consultoria estratégica",
      }),
      storage.createInvoice({
        customerId: customers[1].id,
        organizationId: org.id,
        invoiceNumber: `INV-${Date.now()}-011`,
        amount: "1900.00",
        status: "pending",
        issueDate: new Date(now.getFullYear(), now.getMonth(), 8),
        dueDate: new Date(now.getFullYear(), now.getMonth(), 18),
        description: "Treinamento de equipe",
      }),
      // Fatura vencida
      storage.createInvoice({
        customerId: customers[2].id,
        organizationId: org.id,
        invoiceNumber: `INV-${Date.now()}-012`,
        amount: "3800.00",
        status: "overdue",
        issueDate: new Date(now.getFullYear(), now.getMonth() - 1, 20),
        dueDate: new Date(now.getFullYear(), now.getMonth() - 1, 30),
        description: "Manutenção corretiva urgente",
      }),
    ]);
    console.log("✓ Created", invoices.length, "invoices");

    console.log("\n✅ Seed completed successfully!");
    console.log("\nLogin credentials:");
    console.log("Email: demo@lucrei.com");
    console.log("Password: demo123");
    console.log("\nOr use:");
    console.log("Email: admin@lucrei.com");
    console.log("Password: demo123");

    process.exit(0);
  } catch (error) {
    console.error("❌ Seed failed:", error);
    process.exit(1);
  }
}

seed();
